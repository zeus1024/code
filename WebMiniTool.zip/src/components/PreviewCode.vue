<template>
  <pre class="line-numbers" style="white-space: pre-wrap">
    <code  class='language-html' v-html="Prism.highlight(formatCode, Prism.languages[type], type)"></code>
    </pre>
</template>

<script setup lang="ts">
import { onMounted, ref, watch } from 'vue'
import Prism from 'prismjs'
import { js_beautify, html_beautify, css_beautify } from 'js-beautify'

const props = defineProps({
  code: {
    type: String,
    default: ''
  },
  type: {
    type: String,
    default: 'html'
  }
})

const formatCode = ref('')
watch(
  () => {
    props.code
  },
  () => {
    if (props.type === 'html') {
      console.log(props.code)

      formatCode.value = html_beautify(props.code)
    } else if (props.type === 'js') {
      formatCode.value = js_beautify(props.code)
    }
  },
  {
    deep: true
  }
)

onMounted(() => {
  Prism.highlightAll() //切换菜单重新渲染
})
</script>
<style>
pre.line-numbers,
pre.no-line-numbers {
  white-space: pre-wrap;
}
</style>
