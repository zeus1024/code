<template>
  <div style="border: 1px solid #ccc">
    <Editor
      style="height: 500px"
      v-model="valueHtml"
      :defaultConfig="editorConfig"
      :mode="toolbarConfig.mode"
      @onCreated="handleCreated"
      @onChange="handleChange"
    />
  </div>
  <el-button type="warning" @click="clearEditor">清空编辑器</el-button>
  <el-button type="primary" @click="handleChange(editorRef)">转换</el-button>

  <el-tabs v-model="activeTab">
    <el-tab-pane label="html" name="html"> </el-tab-pane>
    <el-tab-pane label="js" name="js"> </el-tab-pane>
  </el-tabs>

  <div v-if="activeTab === 'html'">
    <el-checkbox-group v-model="htmlCheckbox">
      <el-checkbox label="addThead">添加 thead 标签</el-checkbox>
      <el-checkbox label="addTbody">添加 tbody 标签</el-checkbox>
    </el-checkbox-group>
    <!-- 功能表格 -->
    <el-table :data="htmlCustom" border stripe style="width: 100%" max-height="250">
      <el-table-column width="120">
        <template #header> 功能开关 </template>
        <template #default="scope">第{{ scope.$index }}列</template>
      </el-table-column>
      <el-table-column label="customClass" width="180">
        <template #header>
          <el-switch v-model="htmlToolSwitch.useCustomClass" active-text="自定义class" />
        </template>
        <template #default="scope"> <el-input v-model="scope.row.customClass"></el-input></template>
      </el-table-column>
      <el-table-column label="customWidth" width="180">
        <template #header>
          <el-switch v-model="htmlToolSwitch.useCustomWidth" active-text="自定义width" />
        </template>
        <template #default="scope"> <el-input v-model="scope.row.customWidth"></el-input></template>
      </el-table-column>
    </el-table>
  </div>

  <div v-if="activeTab === 'js'">
    <el-select v-model="jsModel" placeholder="选择模式" size="large">
      <el-option
        v-for="item in jsModelOptions"
        :key="item.value"
        :label="item.label"
        :value="item.value"
      >
        <span style="float: left">{{ item.label }}</span>
        <span style="float: right">
          <el-tooltip :content="item.desc" placement="right">
            <el-icon><QuestionFilled /></el-icon>
          </el-tooltip>
        </span>
      </el-option>
    </el-select>

    <!-- 功能表格 -->
    <el-table :data="jsCustom" border stripe style="width: 100%" max-height="250">
      <el-table-column width="120">
        <template #header> 功能开关 </template>
        <template #default="scope">第{{ scope.$index }}列</template>
      </el-table-column>
      <el-table-column label="customKey" width="180">
        <template #header>
          <el-switch v-model="jsToolSwitch.useCustomKey" active-text="自定义key" />
        </template>
        <template #default="scope"> <el-input v-model="scope.row.customKey"></el-input></template>
      </el-table-column>
      <el-table-column label="splitSymbol" width="180">
        <template #header>
          <el-switch v-model="jsToolSwitch.useSplit" active-text="分隔符集合" />
        </template>
        <template #default="scope"> <el-input v-model="scope.row.splitSymbol"></el-input></template>
      </el-table-column>
    </el-table>
  </div>

  <PreviewCode :code="getCode" :type="activeTab" style="height: 500px"></PreviewCode>

  <div v-if="activeTab === 'html'">
    <div class="preview-table" v-html="getCode"></div>
  </div>
</template>

<script lang="ts" setup>
import '@wangeditor/editor/dist/css/style.css' // 引入 css
import { Editor } from '@wangeditor/editor-for-vue'
import PreviewCode from '@/components/PreviewCode.vue'
import { onBeforeUnmount, ref, shallowRef, onMounted } from 'vue'

import convertHtml from './cpn/ConvertHtml'
import convertJs from './cpn/ConvertJs'

const { htmlCheckbox, htmlCustom, htmlToolSwitch, JsonToHtml, handleDefaultJson } = convertHtml()
const { jsModel, jsModelOptions, jsToolSwitch, jsCustom, handleTreeJson, JsonToJs } = convertJs()
const activeTab = ref('html')

// 编辑器实例，必须用 shallowRef
const editorRef = shallowRef()
const toolbarConfig = {
  mode: 'default' // 或 'simple'
}
const editorConfig = { placeholder: '请输入内容...' }

const handleCreated = (editor: any) => {
  editorRef.value = editor // 记录 editor 实例，重要！
}
onMounted(() => {})

// 内容 HTML
const valueHtml = ref()
// 监听输入内容改变时
const getCode = ref()
const handleChange = (editor: any) => {
  // console.log('change:', editor.children)
  editor.children.forEach((item: any) => {
    if (item.type === 'table') {
      console.log('table', item.children)
      //   处理为默认的JSON数据结构
      let defaultJson = handleDefaultJson(item.children)
      // 处理为树状的Json数据结构
      let TreeJson = handleTreeJson(defaultJson)
      console.log('TreeJson', TreeJson)

      if (activeTab.value === 'html') {
        getCode.value = JsonToHtml(defaultJson)
      }
      if (activeTab.value === 'js') {
        getCode.value = JsonToJs(defaultJson)
      }
    }
  })
  console.log(getCode.value)
}

// 清空编辑器
const clearEditor = () => {
  editorRef.value.clear()
  editorRef.value.children = [
    {
      type: 'paragraph',
      children: [
        {
          text: ''
        }
      ]
    }
  ]
  getCode.value = ''
}

// 组件销毁时，也及时销毁编辑器
onBeforeUnmount(() => {
  const editor = editorRef.value
  if (editor == null) return
  editor.destroy()
})
</script>
<style lang="scss">
.preview-table {
  table,
  th,
  td {
    border: 1px solid #000000;
    border-collapse: collapse;
  }
}
</style>
