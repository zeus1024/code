import { ref, reactive, type Ref, unref } from 'vue'
interface IHtmlCustom {
  customClass: string
  customWidth: string
}
export default function convertHtml() {
  const htmlCheckbox = ref(['addThead', 'addTbody'])
  // html功能开关
  const htmlToolSwitch = reactive({
    useCustomClass: false,
    useCustomWidth: false
  })
  const htmlCustom: Ref<IHtmlCustom[]> = ref([])

  // 生成默认的htmlCustom
  const createHtmlCustom = (columnLength: number) => {
    let htmlCustomInner = unref(htmlCustom)
    htmlCustom.value = []
    for (let i = 0; i < columnLength; i++) {
      let item = htmlCustomInner[i]
      htmlCustom.value.push({
        customClass: item?.customClass || '',
        customWidth: item?.customWidth || ''
      })
    }
    console.log(htmlCustom.value, 'htmlCustom.value')
  }
  // 计算当前真实的columnaIndex
  const getColumnaIndex = (rowLength: number, columnIndex: number) => {
    let columnLength = htmlCustom.value.length
    return columnLength - rowLength + columnIndex
  }
  interface IRowCellJson {
    text: string
    colSpan: number
    rowSpan: number
    width?: string
    class?: string
  }
  //  处理为默认的JSON数据结构
  const handleDefaultJson = (data: any) => {
    let res: any[] = []
    if (data.length === 0) return
    createHtmlCustom(data[0].children.length)
    data.forEach((item: any) => {
      let cellArray: IRowCellJson[] = []
      item.children.forEach((cell: any) => {
        if (!cell.children) return
        cellArray.push({
          text: cell.children[0].text,
          colSpan: cell.colSpan,
          rowSpan: cell.rowSpan
        })
      })
      res.push(cellArray)
    })
    return res
  }

  const JsonToHtml = (jsonArray: any) => {
    let htmlStr = '<table>'
    jsonArray.forEach((item: any, rowIndex: number) => {
      let rowLength = item.length
      if (rowIndex === 0 && htmlCheckbox.value.indexOf('addThead') !== -1) {
        htmlStr += '<thead>'
      }
      if (rowIndex <= 1 && htmlCheckbox.value.indexOf('addTbody') !== -1) {
        if (rowIndex === 0 && htmlCheckbox.value.indexOf('addThead') === -1) htmlStr += '<tbody>'
        if (rowIndex === 1 && htmlCheckbox.value.indexOf('addThead') !== -1) htmlStr += '<tbody>'
      }
      htmlStr += '<tr>'
      // 处理每一行tr
      item.forEach((cell: any, columnIndex: number) => {
        let colSpan = cell.colSpan
        let rowSpan = cell.rowSpan
        let text = cell.text

        // 处理th和td
        if (rowIndex === 0 && htmlCheckbox.value.indexOf('addThead') !== -1) {
          htmlStr += '<th'
        } else {
          htmlStr += '<td'
        }
        // 处理span
        if (colSpan > 1) {
          htmlStr += ` colspan="${colSpan}"`
        }
        if (rowSpan > 1) {
          htmlStr += `  rowspan="${rowSpan}" `
        }

        // 处理自定义class
        let customItem = htmlCustom.value[getColumnaIndex(rowLength, columnIndex)]
        if (htmlToolSwitch.useCustomClass && customItem.customClass) {
          htmlStr += `  class="${customItem.customClass}" `
        }
        // 处理自定义width
        if (htmlToolSwitch.useCustomWidth && customItem.customWidth) {
          htmlStr += `  width="${customItem.customWidth}" `
        }
        // 处理内容的br
        if (text.indexOf('\n') !== -1) {
          text = text.replaceAll('\n\n', '<br/>')
          text = text.replaceAll('\n', '<br/>')
        }

        // 处理th和td
        if (rowIndex === 0 && htmlCheckbox.value.indexOf('addThead') !== -1) {
          htmlStr += '>' + text + '</th>'
        } else {
          htmlStr += '>' + text + '</td>'
        }
      })

      htmlStr += '</tr>'

      if (htmlCheckbox.value.indexOf('addThead') !== -1 && rowIndex === 0) {
        htmlStr += '</thead>'
      }
    })
    if (htmlCheckbox.value.indexOf('addTbody') !== -1) {
      htmlStr += '</tbody>'
    }
    htmlStr += '</table>'
    return htmlStr
  }
  return { htmlCheckbox, htmlToolSwitch, htmlCustom, JsonToHtml, handleDefaultJson }
}
