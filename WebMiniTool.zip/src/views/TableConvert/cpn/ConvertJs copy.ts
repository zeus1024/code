import { ref } from 'vue'
import PreviewCode from '@/components/PreviewCode.vue'

const jsSelect = ref('colModel')
const jsSelectOptions = [
  {
    value: 'infoList',
    label: '业务：用户协议清单',
    desc: '业务：用户协议清单'
  },
  { value: 'common', label: '普通模式', desc: '输出Array Of Object,不适用合并单元格' },
  {
    value: 'colModel',
    label: '合并单元格模式',
    desc: '输出以第一列为核心的Array Of Object,不适用合并单元格'
  },
  {
    value: 'colListModel',
    label: 'objectList',
    desc: '以第一列为key,输出object List,适用合并单元格'
  }
]
const jsCheckbox = ref([])
const jsUseCustomKey = ref(false)
const CustomKeyArray = ref([
  {
    key: '',
    index: 0
  }
])
const JsonToJs = (jsonArray: any) => {
  let res: any[] = []
  let keyArray: any[] = []
  // 处理首行，获取key
  if (jsUseCustomKey.value) {
    CustomKeyArray.value.forEach((item) => {
      keyArray.push(item.key)
    })
  } else {
    jsonArray[0].children.forEach((cell: any) => {
      keyArray.push(cell.children[0].text)
    })
  }

  if (jsSelect.value === 'common') {
    jsonArray.forEach((item: any, rowIndex: number) => {
      let row = item.children
      let cellObj: any = {}

      if (rowIndex !== 0) {
        row.forEach((cell: any, cellIndex: number) => {
          let text = cell.children[0].text
          if (text.indexOf('\n') !== -1) {
            text = text.replaceAll('\n', '')
            text = text.replaceAll(' ', '')
          }
          if (text.indexOf(';') !== -1) {
            text = text.split(';').filter((ele: any) => ele)
          }

          cellObj[keyArray[cellIndex]] = text
        })
        res.push(cellObj)
      }
    })
  }
  if (jsSelect.value === 'colModel') {
    let firstColText = ''
    jsonArray.forEach((item: any, rowIndex: number) => {
      let row = item.children
      let cellObj: any = {}

      if (rowIndex !== 0) {
        let rowLength = row.length
        let keyArrayLength = keyArray.length

        row.forEach((cell: any, cellIndex: number) => {
          // 处理text
          let text = cell.children[0].text
          if (text.indexOf('\n') !== -1) {
            text = text.replaceAll('\n', '')
            text = text.replaceAll(' ', '')
          }
          if (text.indexOf(';') !== -1) {
            text = text.split(';').filter((ele: any) => ele)
          }
          // 取到合并单元格的第一列的text
          if (cellIndex === 0 && rowLength === keyArrayLength) {
            firstColText = text
          }
          // 含有合并单元格
          if (rowLength < keyArrayLength) {
            if (cellIndex === 0) {
              cellObj[keyArray[0]] = firstColText
            }
            cellObj[keyArray[cellIndex + 1]] = text
          } else {
            cellObj[keyArray[cellIndex]] = text
          }
        })
        res.push(cellObj)
      }
    })
  }
  if (jsSelect.value === 'colListModel') {
    colListModel()
  }
  function colListModel() {
    let firstColText = ''
    let rowSpan = 0
    let colList: any[] = []
    jsonArray.forEach((item: any, rowIndex: number) => {
      let row = item.children
      let cellObj: any = {}

      if (rowIndex !== 0) {
        let rowLength = row.length
        let keyArrayLength = keyArray.length

        row.forEach((cell: any, cellIndex: number) => {
          // 处理text
          let text = cell.children[0].text
          if (text.indexOf('\n') !== -1) {
            text = text.replaceAll('\n', '')
            text = text.replaceAll(' ', '')
          }
          if (text.indexOf(';') !== -1) {
            text = text.split(';').filter((ele: any) => ele)
          }
          // 取到合并单元格的第一行的text
          if (cellIndex === 0 && rowLength === keyArrayLength) {
            firstColText = text
            rowSpan = cell.rowSpan
          }
          // 含有合并单元格
          if (rowLength < keyArrayLength) {
            cellObj[keyArray[cellIndex + 1]] = text
          } else {
            if (cellIndex !== 0) {
              cellObj[keyArray[cellIndex]] = text
            }
          }
        })
        colList.push(cellObj)
        rowSpan--
        console.log(rowSpan)

        if (rowSpan < 1) {
          res.push({
            [keyArray[0]]: firstColText,
            list: colList
          })
          colList = []
          firstColText = ''
        }
      }
    })
  }

  if (jsSelect.value === 'infoList') {
    keyArray = ['type', 'content', 'func', 'purpose']
    colListModel()
    res.forEach((item) => {
      item.list.forEach((item2: any) => {
        item2.title = item2.content
      })
    })
  }

  return JSON.stringify(res)
}
export { jsSelect, jsSelectOptions, jsCheckbox, jsUseCustomKey, CustomKeyArray, JsonToJs }
