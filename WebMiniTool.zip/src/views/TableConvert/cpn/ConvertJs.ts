import { reactive, ref, type Ref, unref } from 'vue'
interface IJsCustom {
  customKey: string
  splitSymbol: string
}
export default function convertJs() {
  // 选择js的输出模式
  const jsModel = ref('')
  const jsModelOptions = [
    {
      value: 'infoList',
      label: '业务：用户协议清单',
      desc: '业务：用户协议清单'
    },
    {
      value: 'treeJson',
      label: '输出树状JSON',
      desc: '输出树状JSON，适用于合并单元格。如果没有合并单元格，则是平铺的'
    },
    {
      value: 'defaultJson',
      label: '输出未经处理的JSON',
      desc: '输出未经处理的JSON，非树状，含有rowspan，可用于处理数据。该JSON用于生成HTML格式的内容'
    }
  ]
  // js功能开关
  const jsToolSwitch = reactive({
    useCustomKey: true,
    useSplit: false
  })

  const columnKeyArray: Ref<string[]> = ref([]) //用于输出的列名

  const jsCustom: Ref<IJsCustom[]> = ref([])

  // 生成默认的jsCustom
  const createjsCustom = (columnLength: number) => {
    let jsCustomInner = unref(jsCustom)
    jsCustom.value = []
    for (let i = 0; i < columnLength; i++) {
      let item = jsCustomInner[i]
      jsCustom.value.push({
        customKey: item?.customKey || `column${i}`,
        splitSymbol: item?.splitSymbol || ''
      })
    }
    console.log(jsCustom.value, 'jsCustom.value')
  }
  // 计算当前真实的columnaIndex
  const getColumnaIndex = (rowLength: number, columnIndex: number) => {
    let columnLength = jsCustom.value.length
    return columnLength - rowLength + columnIndex
  }
  // JSON转js
  const JsonToJs = (data: any) => {
    let res = handleTreeJson(data)
    return JSON.stringify(res)
  }
  // 处理为树状的Json数据结构
  const handleTreeJson = (data: any) => {
    let res: any[] = []
    console.log(data, 'data')
    let treeArray: any[] = []
    let cellLength = data[0].length
    createjsCustom(cellLength)

    data.forEach((item: any, rowIndex: number) => {
      let rowLength = item.length
      if (rowLength < cellLength) return
      let cellObj: any = {}
      let rowSpanFlag = 0
      item.forEach((cell: any, columnIndex: number) => {
        if (rowSpanFlag) return
        let colSpan = cell.colSpan
        let rowSpan = cell.rowSpan
        let trueColumnIndex = getColumnaIndex(rowLength, columnIndex)
        let columnName = jsCustom.value[trueColumnIndex].customKey
        let text = handleText(cell.text, trueColumnIndex)

        if (rowSpan > 1) {
          rowSpanFlag = 1
          let children = handleColumn(data, rowIndex, columnIndex, rowSpan)
          cellObj[columnName] = text
          cellObj.children = children
        } else {
          cellObj[columnName] = text
        }
      })
      treeArray.push(cellObj)
    })

    return treeArray
  }

  // 处理树状Children
  const handleColumn = (data: any, rowIndex: number, cellIndex: number, rowSpan: number) => {
    let children: any[] = []

    for (let i = 0; i < rowSpan; i++) {
      let cellObj: any = {}
      let rowSpanFlag = 0
      let rowLength = data[rowIndex + i].length
      data[rowIndex + i].forEach((cell: any, columnIndex: number) => {
        if (i === 0) {
          if (columnIndex <= cellIndex) return
        }
        if (rowSpanFlag) return

        let colSpan = cell.colSpan
        let rowSpan = cell.rowSpan
        let trueColumnIndex = getColumnaIndex(rowLength, columnIndex)
        let columnName = jsCustom.value[trueColumnIndex].customKey
        let text = handleText(cell.text, trueColumnIndex)

        if (rowSpan > 1) {
          rowSpanFlag = 1
          let children = handleColumn(data, rowIndex + i, columnIndex, rowSpan)
          cellObj[columnName] = text
          cellObj.children = children
          i = i + rowSpan - 1
        } else {
          cellObj[columnName] = text
        }
      })
      children.push(cellObj)
    }
    return children
  }
  // 处理text
  const handleText = (text: string, columnIndex: number) => {
    let res: any = text
    if (jsToolSwitch.useSplit) {
      let splitArray = jsCustom.value[columnIndex].splitSymbol.split('')
      if (!splitArray.length) return res
      let res2: any = []
      splitArray.forEach((item, index) => {
        if (typeof res === 'string')
          if (res.indexOf(item) !== -1) res = res.split(item).filter((ele: any) => ele)

        if (typeof res === 'object') {
          res.forEach((item2: any, index: number) => {
            console.log(...item2.split(item).filter((ele: any) => ele))
            let arr = item2.split(item).filter((ele: any) => ele)
            if (arr.length) {
              res2.splice(index, 1)
            }
            res2.push(...arr)
          })
        }
      })
      if (res2.length) res = res2
    }
    return res
  }
  return {
    jsModel,
    jsModelOptions,
    jsToolSwitch,
    columnKeyArray,
    jsCustom,
    createjsCustom,
    handleTreeJson,
    handleColumn,
    JsonToJs
  }
}
