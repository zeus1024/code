<template>
  <el-button type="primary" @click="clearEditor">清空编辑器</el-button>

  <div style="border: 1px solid #ccc">
    <!-- <Toolbar
        style="border-bottom: 1px solid #ccc"
        :editor="editorRef"
        :defaultConfig="toolbarConfig"
        :mode="toolbarConfig.mode"
      /> -->
    <Editor
      style="height: 500px"
      v-model="valueHtml"
      :defaultConfig="editorConfig"
      :mode="toolbarConfig.mode"
      @onCreated="handleCreated"
      @onChange="handleChange"
    />
  </div>
  <el-tabs v-model="activeTab">
    <el-tab-pane label="html" name="html"> </el-tab-pane>
    <el-tab-pane label="js" name="js"> </el-tab-pane>
  </el-tabs>
  <div v-if="activeTab === 'html'">
    <el-checkbox-group v-model="htmlCheckbox">
      <el-checkbox label="showThead">添加 thead 和 tbody 标签</el-checkbox>
    </el-checkbox-group>
  </div>

  <div v-if="activeTab === 'js'">
    <el-select v-model="jsSelect" placeholder="选择模式" size="large">
      <el-option
        v-for="item in jsSelectOptions"
        :key="item.value"
        :label="item.label"
        :value="item.value"
      />
    </el-select>
    <!-- <el-checkbox-group v-if="activeTab === 'js'" v-model="jsCheckbox">
      <el-checkbox label="firstAsKey">以第一行为key</el-checkbox>
      <el-checkbox label="userMyKey">自定义key</el-checkbox>
    </el-checkbox-group> -->
    <el-switch v-model="jsUseCustomKey" active-text="自定义key" inactive-text="默认以第一行为key" />
    <div v-if="jsUseCustomKey">
      <template v-for="(item, index) in CustomKeyArray">
        key:{{ index }} <el-input v-model="item.key"></el-input>
      </template>
      <el-button @click="CustomKeyArray.push({ key: '', index: CustomKeyArray.length })"
        >+1</el-button
      >
    </div>
  </div>

  <PreviewCode :code="getCode" :type="activeTab" style="height: 500px"></PreviewCode>
  <div v-if="activeTab === 'html'">
    <div class="preview-table" v-html="getCode"></div>
  </div>
</template>

<script lang="ts" setup>
import '@wangeditor/editor/dist/css/style.css' // 引入 css
import { Editor, Toolbar } from '@wangeditor/editor-for-vue'

import { onBeforeUnmount, ref, shallowRef, onMounted } from 'vue'
import PreviewCode from '@/components/PreviewCode.vue'

const activeTab = ref('html')
const htmlCheckbox = ref(['showThead'])

const jsSelect = ref('colModel')
const jsSelectOptions = [
  {
    value: 'infoList',
    label: '业务：用户协议清单',
    desc: '业务：用户协议清单'
  },
  { value: 'common', label: '普通模式', desc: '输出Array Of Object,不适用合并单元格' },
  {
    value: 'colModel',
    label: '合并单元格模式',
    desc: '输出以第一列为核心的Array Of Object,不适用合并单元格'
  },
  {
    value: 'colListModel',
    label: 'objectList',
    desc: '以第一列为key,输出object List,适用合并单元格'
  }
]
const jsCheckbox = ref([])
const jsUseCustomKey = ref(false)
const CustomKeyArray = ref([
  {
    key: '',
    index: 0
  }
])
// 编辑器实例，必须用 shallowRef
const editorRef = shallowRef()
const toolbarConfig = {
  mode: 'default' // 或 'simple'
}
const editorConfig = { placeholder: '请输入内容...' }

const handleCreated = (editor: any) => {
  editorRef.value = editor // 记录 editor 实例，重要！
}
onMounted(() => {})

// 内容 HTML
const valueHtml = ref()
// 监听输入内容改变时
const getCode = ref()
const handleChange = (editor: any) => {
  // console.log('change:', editor.children)
  editor.children.forEach((item: any) => {
    if (item.type === 'table') {
      console.log('table', item.children)
      //   处理默认输出的JSON数据结构
      let DefaultJson = handleDefaultJson(item.children)
      if (activeTab.value === 'html') {
        getCode.value = JsonToHtml(DefaultJson)
      }
      if (activeTab.value === 'js') {
        getCode.value = JsonToJs(item.children)
      }
    }
  })
  console.log(getCode.value)
}
//   处理默认输出的JSON数据结构
interface IRowCellJson {
  text: string
  colSpan: number
  rowSpan: number
  width?: string
  class?: string
}

const handleDefaultJson = (data: any) => {
  let res: any[] = []
  if (data.length === 0) return
  data.forEach((item: any) => {
    let cellArray: IRowCellJson[] = []
    item.children.forEach((cell: any) => {
      cellArray.push({ text: cell.children[0].text, colSpan: cell.colSpan, rowSpan: cell.rowSpan })
    })
    res.push(cellArray)
  })
  return res
}
const JsonToHtml = (jsonArray: any) => {
  let htmlStr = '<table>'
  jsonArray.forEach((item: any, rowIndex: number) => {
    if (rowIndex < 2 && htmlCheckbox.value.indexOf('showThead') !== -1) {
      if (rowIndex === 0) {
        htmlStr += '<thead>'
      }
      if (rowIndex === 1) {
        htmlStr += '<tbody>'
      }
    }
    htmlStr += '<tr>'
    // 处理每一行tr
    item.forEach((cell: any) => {
      let colSpan = cell.colSpan
      let rowSpan = cell.rowSpan
      let text = cell.text

      // 处理th和td
      if (rowIndex === 0 && htmlCheckbox.value.indexOf('showThead') !== -1) {
        htmlStr += '<th'
      } else {
        htmlStr += '<td'
      }
      // 处理span
      if (colSpan > 1) {
        htmlStr += ` colspan="${colSpan}"`
      }
      if (rowSpan > 1) {
        htmlStr += `  rowspan="${rowSpan}" `
      }

      // 处理内容的br
      if (text.indexOf('\n') !== -1) {
        text = text.replaceAll('\n\n', '<br/>')
        text = text.replaceAll('\n', '<br/>')
      }

      // 处理th和td
      if (rowIndex === 0 && htmlCheckbox.value.indexOf('showThead') !== -1) {
        htmlStr += '>' + text + '</th>'
      } else {
        htmlStr += '>' + text + '</td>'
      }
    })

    htmlStr += '</tr>'

    if (htmlCheckbox.value.indexOf('showThead') !== -1 && rowIndex === 0) {
      htmlStr += '</thead>'
    }
  })
  if (htmlCheckbox.value.indexOf('showThead') !== -1) {
    htmlStr += '</tbody>'
  }
  htmlStr += '</table>'
  return htmlStr
}

const JsonToJs = (jsonArray: any) => {
  let res: any[] = []
  let keyArray: any[] = []
  // 处理首行，获取key
  if (jsUseCustomKey.value) {
    CustomKeyArray.value.forEach((item) => {
      keyArray.push(item.key)
    })
  } else {
    jsonArray[0].children.forEach((cell: any) => {
      keyArray.push(cell.children[0].text)
    })
  }

  if (jsSelect.value === 'common') {
    jsonArray.forEach((item: any, rowIndex: number) => {
      let row = item.children
      let cellObj: any = {}

      if (rowIndex !== 0) {
        row.forEach((cell: any, cellIndex: number) => {
          let text = cell.children[0].text
          if (text.indexOf('\n') !== -1) {
            text = text.replaceAll('\n', '')
            text = text.replaceAll(' ', '')
          }
          if (text.indexOf(';') !== -1) {
            text = text.split(';').filter((ele: any) => ele)
          }

          cellObj[keyArray[cellIndex]] = text
        })
        res.push(cellObj)
      }
    })
  }
  if (jsSelect.value === 'colModel') {
    let firstColText = ''
    jsonArray.forEach((item: any, rowIndex: number) => {
      let row = item.children
      let cellObj: any = {}

      if (rowIndex !== 0) {
        let rowLength = row.length
        let keyArrayLength = keyArray.length

        row.forEach((cell: any, cellIndex: number) => {
          // 处理text
          let text = cell.children[0].text
          if (text.indexOf('\n') !== -1) {
            text = text.replaceAll('\n', '')
            text = text.replaceAll(' ', '')
          }
          if (text.indexOf(';') !== -1) {
            text = text.split(';').filter((ele: any) => ele)
          }
          // 取到合并单元格的第一列的text
          if (cellIndex === 0 && rowLength === keyArrayLength) {
            firstColText = text
          }
          // 含有合并单元格
          if (rowLength < keyArrayLength) {
            if (cellIndex === 0) {
              cellObj[keyArray[0]] = firstColText
            }
            cellObj[keyArray[cellIndex + 1]] = text
          } else {
            cellObj[keyArray[cellIndex]] = text
          }
        })
        res.push(cellObj)
      }
    })
  }
  if (jsSelect.value === 'colListModel') {
    colListModel()
  }
  function colListModel() {
    let firstColText = ''
    let rowSpan = 0
    let colList: any[] = []
    jsonArray.forEach((item: any, rowIndex: number) => {
      let row = item.children
      let cellObj: any = {}

      if (rowIndex !== 0) {
        let rowLength = row.length
        let keyArrayLength = keyArray.length

        row.forEach((cell: any, cellIndex: number) => {
          // 处理text
          let text = cell.children[0].text
          if (text.indexOf('\n') !== -1) {
            text = text.replaceAll('\n', '')
            text = text.replaceAll(' ', '')
          }
          if (text.indexOf(';') !== -1) {
            text = text.split(';').filter((ele: any) => ele)
          }
          // 取到合并单元格的第一行的text
          if (cellIndex === 0 && rowLength === keyArrayLength) {
            firstColText = text
            rowSpan = cell.rowSpan
          }
          // 含有合并单元格
          if (rowLength < keyArrayLength) {
            cellObj[keyArray[cellIndex + 1]] = text
          } else {
            if (cellIndex !== 0) {
              cellObj[keyArray[cellIndex]] = text
            }
          }
        })
        colList.push(cellObj)
        rowSpan--
        console.log(rowSpan)

        if (rowSpan < 1) {
          res.push({
            [keyArray[0]]: firstColText,
            list: colList
          })
          colList = []
          firstColText = ''
        }
      }
    })
  }

  if (jsSelect.value === 'infoList') {
    keyArray = ['type', 'content', 'func', 'purpose']
    colListModel()
    res.forEach((item) => {
      item.list.forEach((item2: any) => {
        item2.title = item2.content
      })
    })
  }

  return JSON.stringify(res)
}

const clearEditor = () => {
  editorRef.value.clear()
  editorRef.value.children = [
    {
      type: 'paragraph',
      children: [
        {
          text: ''
        }
      ]
    }
  ]
  getCode.value = ''
}

// 组件销毁时，也及时销毁编辑器
onBeforeUnmount(() => {
  const editor = editorRef.value
  if (editor == null) return
  editor.destroy()
})
</script>
<style lang="scss">
.preview-table {
  table,
  th,
  td {
    border: 1px solid #000000;
    border-collapse: collapse;
  }
}
</style>
