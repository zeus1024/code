<template>
  <div>
    <RouterView></RouterView>
  </div>
</template>

<script setup lang="ts"></script>

<style scoped></style>
